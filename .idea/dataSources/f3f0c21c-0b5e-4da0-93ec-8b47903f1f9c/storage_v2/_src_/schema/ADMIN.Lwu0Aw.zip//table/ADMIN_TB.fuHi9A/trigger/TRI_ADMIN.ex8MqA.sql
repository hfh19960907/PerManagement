create trigger TRI_ADMIN
  before insert
  on ADMIN_TB
  for each row
  declare
begin
  if :new.admin_id is null or :new.admin_id=0 then
select seq_admin.nextval into :new.admin_id from sys.dual;
end if;
end tri_admin;
/

