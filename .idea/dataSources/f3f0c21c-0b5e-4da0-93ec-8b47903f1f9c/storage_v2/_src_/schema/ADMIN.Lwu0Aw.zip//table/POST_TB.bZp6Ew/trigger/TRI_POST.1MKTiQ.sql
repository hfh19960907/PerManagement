create trigger TRI_POST
  before insert
  on POST_TB
  for each row
  declare
  -- local variables here
begin
  if:new.post_id is null or :new.post_id=0 then
  select seq_post.nextval into :new.post_id from dual;
  end if;
end tri_post;
/

