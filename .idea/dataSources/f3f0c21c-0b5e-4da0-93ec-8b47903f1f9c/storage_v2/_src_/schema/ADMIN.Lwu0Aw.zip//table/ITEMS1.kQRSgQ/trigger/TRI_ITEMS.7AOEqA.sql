create trigger TRI_ITEMS
  before insert
  on ITEMS1
  for each row
  when (NEW.ID IS NULL)
  BEGIN
    SELECT seq_items.NEXTVAL INTO:NEW.ID FROM DUAL;
END;
/

