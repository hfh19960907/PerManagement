create trigger TRI_POS
  before insert
  on POSITION_TB
  for each row
  declare
  -- local variables here
begin
  if:new.pos_id is null or:new.pos_id=0 then
  select seq_pos.nextval into:new.pos_id from dual;
  end if;
end tri_pos;
/

