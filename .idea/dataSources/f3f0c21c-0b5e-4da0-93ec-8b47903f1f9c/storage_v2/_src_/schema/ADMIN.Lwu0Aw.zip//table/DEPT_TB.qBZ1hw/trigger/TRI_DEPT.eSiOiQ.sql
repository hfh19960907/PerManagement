create trigger TRI_DEPT
  before insert
  on DEPT_TB
  for each row
  declare
  -- local variables here
begin
  if:new.dept_id is null or:new.dept_id=0 then
  select seq_dept.nextval into :new.dept_id from dual;
  end if;
end tri_dept;
/

